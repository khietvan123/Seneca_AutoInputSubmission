﻿using System;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Windows.Forms;

namespace hi
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            // Path to the Python interpreter
            //string pythonPath = @"C:\Users\joann\AppData\Local\Microsoft\WindowsApps\python.exe";
            string pythonPath = FindPythonPath();

            // Path to the Python script file
            string pythonScript = @"gui.py"; // Change this to the path of your Python script

            // Check if the Python interpreter and script file exist
            if (pythonPath == null)
            {
                MessageBox.Show("Python interpreter not found.");
                return;
            }

            if (!System.IO.File.Exists(pythonScript))
            {
                MessageBox.Show("'test.txt' script not found.");
                return;
            }

            ProcessStartInfo startInfo = new ProcessStartInfo
            {
                FileName = pythonPath,
                Arguments = pythonScript,
                UseShellExecute = false,
                RedirectStandardOutput = true,
                RedirectStandardError = true,
                CreateNoWindow = true
            };

            using (Process process = Process.Start(startInfo))
            {
                // Read the standard output and error
                string output = process.StandardOutput.ReadToEnd();
                string error = process.StandardError.ReadToEnd();

                // Display output and error
                MessageBox.Show("Output:\n" + output + "\nError:\n" + error);
            }

            MessageBox.Show("GUI created by Khiet Van Phan <3");
        }

        private string FindPythonPath()
        {
            string pythonPath = null;

            // Attempt to find Python executable in PATH environment variable
            string[] paths = Environment.GetEnvironmentVariable("PATH").Split(';');
            foreach (string path in paths)
            {
                string pythonExePath = Path.Combine(path, "python.exe");
                if (File.Exists(pythonExePath))
                {
                    pythonPath = pythonExePath;
                    break;
                }
            }

            return pythonPath;
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            Label Title = new Label();
            Title.Text = "Thank you, GUI made by Khiet Van Phan <3";
            Title.AutoSize = true;
            Title.Location = new System.Drawing.Point(96, 54);
            Title.BackColor = Color.White;
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            // Get the directory where the application is running
            string appDirectory = AppDomain.CurrentDomain.BaseDirectory;

            // Open file explorer at the application directory
            Process.Start("explorer.exe", appDirectory);
        }
    }
}
