import pyautogui as gui
import time

print('Click on the terminal/console window where the automated keyboard data needs to be entered')
print('NOTE: you have 5s to do this!')
time.sleep(3)

with open('test.txt','r') as tst:
    time.sleep(1)
    tst = tst.readlines()
    for i in range(0, len(tst), 1):
        print(tst[i])
        gui.typewrite(tst[i])


print('Auto data input completed')